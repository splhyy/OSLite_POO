namespace OSLite.Domain.Enums
{
    public enum StatusOS
    {
        Aberta,
        EmExecucao,
        Concluida,
        Cancelada
    }
}
