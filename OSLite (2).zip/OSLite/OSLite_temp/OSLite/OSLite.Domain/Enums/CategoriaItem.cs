namespace OSLite.Domain.Enums
{
    public enum CategoriaItem
    {
        Diagnostico,
        Pecas,
        MaoDeObra
    }
}
