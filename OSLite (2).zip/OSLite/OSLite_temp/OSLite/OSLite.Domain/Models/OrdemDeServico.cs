using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using OSLite.Domain.Enums;
using OSLite.Domain.ValueObjects;

namespace OSLite.Domain.Models
{
    public sealed class OrdemDeServico
    {
        private readonly List<ItemDeServico> _itens = new();
        private Cliente _cliente;

        public int Id { get; private set; }
        public int ClienteId { get; private set; }
        public Cliente Cliente
        {
            get => _cliente;
            private set
            {
                var previous = _cliente;
                if (previous != value)
                {
                    previous?.RemoveOrdemInternal(this);
                    _cliente = value ?? throw new ArgumentNullException(nameof(Cliente));
                    ClienteId = _cliente.Id;
                    _cliente.AddOrdemInternal(this);
                }
            }
        }

        public DateOnly DataAbertura { get; private set; }
        public StatusOS Status { get; private set; }
        public IReadOnlyCollection<ItemDeServico> Itens => new ReadOnlyCollection<ItemDeServico>(_itens);

        private OrdemDeServico(int id, Cliente cliente, DateOnly dataAbertura)
        {
            Id = id;
            _cliente = cliente ?? throw new ArgumentNullException(nameof(cliente));
            ClienteId = cliente.Id;
            DataAbertura = dataAbertura;
            Status = StatusOS.Aberta;
            cliente.AddOrdemInternal(this);
        }

        public static OrdemDeServico Abrir(int id, Cliente cliente, DateOnly? data = null)
        {
            return new OrdemDeServico(id, cliente, data ?? DateOnly.FromDateTime(DateTime.UtcNow));
        }

        public void TrocarCliente(Cliente novoCliente)
        {
            if (novoCliente == null) throw new ArgumentNullException(nameof(novoCliente));
            if (Status == StatusOS.Concluida || Status == StatusOS.Cancelada)
                throw new InvalidOperationException("Não é permitido trocar cliente em OS concluída ou cancelada.");
            Cliente = novoCliente;
        }

        public void AdicionarItem(ItemDeServico item)
        {
            if (item == null) throw new ArgumentNullException(nameof(item));
            if (Status == StatusOS.Concluida || Status == StatusOS.Cancelada)
                throw new InvalidOperationException("Não é permitido adicionar itens quando a OS está Concluída ou Cancelada.");
            _itens.Add(item);
        }

        public void RemoverItem(ItemDeServico item)
        {
            if (item == null) throw new ArgumentNullException(nameof(item));
            if (Status == StatusOS.Concluida || Status == StatusOS.Cancelada)
                throw new InvalidOperationException("Não é permitido remover itens quando a OS está Concluída ou Cancelada.");
            _itens.Remove(item);
        }

        public Money Total() => _itens.Aggregate(Money.Zero, (acc, it) => new(acc.Value + it.Subtotal().Value));

        public void IniciarExecucao()
        {
            if (Status != StatusOS.Aberta) throw new InvalidOperationException("Só é possível iniciar execução a partir do status Aberta.");
            if (!_itens.Any()) throw new InvalidOperationException("Não é possível iniciar execução sem pelo menos um item.");
            Status = StatusOS.EmExecucao;
        }

        public void Concluir()
        {
            if (Status != StatusOS.EmExecucao) throw new InvalidOperationException("Só é possível concluir quando em execução.");
            Status = StatusOS.Concluida;
        }

        public void Cancelar()
        {
            if (Status == StatusOS.Concluida) throw new InvalidOperationException("Não é possível cancelar uma OS já concluída.");
            Status = StatusOS.Cancelada;
        }
    }
}
