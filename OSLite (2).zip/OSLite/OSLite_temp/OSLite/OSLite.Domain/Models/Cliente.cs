using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using OSLite.Domain.ValueObjects;

namespace OSLite.Domain.Models
{
    public class Cliente
    {
        private readonly List<OrdemDeServico> _ordens = new();
        public int Id { get; private set; }
        public string Nome { get; private set; }
        public Email? Email { get; private set; }
        public string? Telefone { get; private set; }

        public Cliente(int id, string nome, Email? email = null, string? telefone = null)
        {
            if (string.IsNullOrWhiteSpace(nome)) throw new ArgumentException("Nome do cliente não pode ser vazio.", nameof(nome));
            Id = id;
            Nome = nome;
            Email = email;
            Telefone = telefone;
        }

        public IReadOnlyCollection<OrdemDeServico> Ordens => new ReadOnlyCollection<OrdemDeServico>(_ordens);

        internal void AddOrdemInternal(OrdemDeServico os)
        {
            if (!_ordens.Contains(os))
                _ordens.Add(os);
        }

        internal void RemoveOrdemInternal(OrdemDeServico os)
        {
            _ordens.Remove(os);
        }
    }
}
