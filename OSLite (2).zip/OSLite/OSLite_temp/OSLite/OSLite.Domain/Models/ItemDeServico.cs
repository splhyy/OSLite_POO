using System;
using OSLite.Domain.ValueObjects;
using OSLite.Domain.Enums;

namespace OSLite.Domain.Models
{
    public sealed class ItemDeServico
    {
        public string Descricao { get; }
        public int Quantidade { get; }
        public Money PrecoUnitario { get; }
        public CategoriaItem? Categoria { get; }

        public ItemDeServico(string descricao, int quantidade, Money precoUnitario, CategoriaItem? categoria = null)
        {
            if (string.IsNullOrWhiteSpace(descricao)) throw new ArgumentException("Descricao não pode ser vazia.", nameof(descricao));
            if (quantidade <= 0) throw new ArgumentOutOfRangeException(nameof(quantidade), "Quantidade deve ser maior que zero.");
            Descricao = descricao;
            Quantidade = quantidade;
            PrecoUnitario = precoUnitario;
            Categoria = categoria;
        }

        public Money Subtotal() => PrecoUnitario.Multiply(Quantidade);
    }
}
