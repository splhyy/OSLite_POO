using System;

namespace OSLite.Domain.ValueObjects
{
    public readonly record struct Money(decimal Value)
    {
        public Money(decimal value) : this(Value: value)
        {
            if (value < 0) throw new ArgumentOutOfRangeException(nameof(value), "Money value cannot be negative.");
        }

        public static Money Zero => new(0m);

        public Money Add(Money other) => new(this.Value + other.Value);
        public Money Multiply(int quantity) => new(this.Value * quantity);

        public override string ToString() => Value.ToString("C");
    }
}
