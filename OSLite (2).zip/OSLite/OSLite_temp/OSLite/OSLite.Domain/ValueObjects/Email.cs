using System;
using System.Text.RegularExpressions;

namespace OSLite.Domain.ValueObjects
{
    public sealed record Email
    {
        private static readonly Regex SimpleEmail = new(@"^[^@\s]+@[^@\s]+\.[^@\s]+$", RegexOptions.Compiled);
        public string Address { get; }

        public Email(string address)
        {
            if (string.IsNullOrWhiteSpace(address)) throw new ArgumentException("Email cannot be empty.", nameof(address));
            if (!SimpleEmail.IsMatch(address)) throw new ArgumentException("Email format is invalid.", nameof(address));
            Address = address;
        }

        public override string ToString() => Address;
    }
}
