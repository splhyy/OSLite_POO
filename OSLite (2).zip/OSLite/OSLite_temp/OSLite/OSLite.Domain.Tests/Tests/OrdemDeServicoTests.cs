using System;
using FluentAssertions;
using OSLite.Domain.Enums;
using OSLite.Domain.Models;
using OSLite.Domain.ValueObjects;
using Xunit;

namespace OSLite.Domain.Tests
{
    public class OrdemDeServicoTests
    {
        [Fact]
        public void OS_total_soma_subtotais_itens()
        {
            var cliente = new Cliente(1, "Ana");
            var os = OrdemDeServico.Abrir(1, cliente);
            os.AdicionarItem(new ItemDeServico("Servico A", 1, new Money(10m)));
            os.AdicionarItem(new ItemDeServico("Servico B", 3, new Money(5m)));
            os.Total().Value.Should().Be(25m);
        }

        [Fact]
        public void OS_aberta_inicia_execucao_quando_tem_itens()
        {
            var cliente = new Cliente(2, "Beto");
            var os = OrdemDeServico.Abrir(2, cliente);
            os.AdicionarItem(new ItemDeServico("S", 1, new Money(1m)));
            os.IniciarExecucao();
            os.Status.Should().Be(StatusOS.EmExecucao);
        }

        [Fact]
        public void OS_aberta_nao_inicia_sem_itens()
        {
            var cliente = new Cliente(3, "Cris");
            var os = OrdemDeServico.Abrir(3, cliente);
            Action act = () => os.IniciarExecucao();
            act.Should().Throw<InvalidOperationException>();
        }

        [Fact]
        public void OS_nao_adiciona_itens_em_concluida_ou_cancelada()
        {
            var cliente = new Cliente(4, "Dani");
            var os = OrdemDeServico.Abrir(4, cliente);
            os.AdicionarItem(new ItemDeServico("S", 1, new Money(1m)));
            os.IniciarExecucao();
            os.Concluir();
            Action add = () => os.AdicionarItem(new ItemDeServico("X", 1, new Money(1m)));
            add.Should().Throw<InvalidOperationException>();
        }

        [Fact]
        public void OS_fluxo_aberta_para_execucao_para_concluida()
        {
            var cliente = new Cliente(5, "E");
            var os = OrdemDeServico.Abrir(5, cliente);
            os.AdicionarItem(new ItemDeServico("S", 1, new Money(1m)));
            os.IniciarExecucao();
            os.Concluir();
            os.Status.Should().Be(StatusOS.Concluida);
        }
    }
}
