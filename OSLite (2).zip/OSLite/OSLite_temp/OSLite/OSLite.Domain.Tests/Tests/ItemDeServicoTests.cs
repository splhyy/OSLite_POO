using System;
using FluentAssertions;
using OSLite.Domain.Models;
using OSLite.Domain.ValueObjects;
using Xunit;

namespace OSLite.Domain.Tests
{
    public class ItemDeServicoTests
    {
        [Fact]
        public void ItemDeServico_cria_valido_e_calcula_subtotal()
        {
            var item = new ItemDeServico("Troca de placa", 2, new Money(50m));
            item.Subtotal().Value.Should().Be(100m);
        }

        [Fact]
        public void ItemDeServico_nao_permite_quantidade_zero_ou_negativa()
        {
            Action act = () => new ItemDeServico("X", 0, new Money(1m));
            act.Should().Throw<ArgumentOutOfRangeException>();
        }
    }
}
