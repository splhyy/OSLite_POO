using System;
using FluentAssertions;
using OSLite.Domain.ValueObjects;
using Xunit;

namespace OSLite.Domain.Tests
{
    public class MoneyTests
    {
        [Fact]
        public void Money_nao_aceita_negativo()
        {
            Action act = () => new Money(-1m);
            act.Should().Throw<ArgumentOutOfRangeException>();
        }

        [Fact]
        public void Money_multiplica_corretamente()
        {
            var m = new Money(10m);
            var result = m.Multiply(3);
            result.Value.Should().Be(30m);
        }
    }
}
