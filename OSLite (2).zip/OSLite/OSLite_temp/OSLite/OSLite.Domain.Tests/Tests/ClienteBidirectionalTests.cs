using FluentAssertions;
using OSLite.Domain.Models;
using Xunit;

namespace OSLite.Domain.Tests
{
    public class ClienteBidirectionalTests
    {
        [Fact]
        public void Cliente_adiciona_ordem_sincroniza_cliente_na_ordem()
        {
            var cliente = new Cliente(10, "Fulano");
            var os = OrdemDeServico.Abrir(10, cliente);
            cliente.Ordens.Should().Contain(os);
            os.Cliente.Should().Be(cliente);
            os.ClienteId.Should().Be(cliente.Id);
        }

        [Fact]
        public void OS_trocar_de_cliente_atualiza_colecoes_dos_clientes()
        {
            var c1 = new Cliente(11, "C1");
            var c2 = new Cliente(12, "C2");
            var os = OrdemDeServico.Abrir(11, c1);
            os.TrocarCliente(c2);
            c1.Ordens.Should().NotContain(os);
            c2.Ordens.Should().Contain(os);
            os.Cliente.Should().Be(c2);
        }
    }
}
